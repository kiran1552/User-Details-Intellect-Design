package com.user_details.springboot;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.web.client.RestTemplate;

import com.user_details.springboot.model.User;

public class UserDetailsRestTest {
	
	public static final String REST_URI = "http://localhost:8080/user_details_intellectdesign/api";
    
    // GET 
    @SuppressWarnings("unchecked")
    private static void listAllUsers(){
        System.out.println("Display all Users-----------");
         
        RestTemplate restTemplate = new RestTemplate();
        List<LinkedHashMap<String, Object>> usersMap = restTemplate.getForObject(REST_URI+"/user/", List.class);
         
        if(usersMap!=null){
            for(LinkedHashMap<String, Object> map : usersMap){
                System.out.println("User : id="+map.get("id")+", Name="+map.get("name")+", Age="+map.get("age"));;
            }
        }else{
            System.out.println("User is not available");
        }
    }
     
    // GET 
    private static void getUser(){
        System.out.println("Get User by id");
        RestTemplate restTemplate = new RestTemplate();
        User user = restTemplate.getForObject(REST_URI+"/user/1", User.class);
        System.out.println(user);
    }
     
    // POST 
    private static void createUser() {
        System.out.println("Create a new User----------");
        RestTemplate restTemplate = new RestTemplate();
        User user = new User(0,"Pravin",51);
        URI uri = restTemplate.postForLocation(REST_URI+"/user/", user, User.class);
       
    }
 
    // PUT 
    private static void updateUser() {
        System.out.println("Update a existing User----------");
        RestTemplate restTemplate = new RestTemplate();
        User user  = new User(1,"KiranRaj",33);
        restTemplate.put(REST_URI+"/user/1", user);
        System.out.println(user);
    }
      
    // DELETE
    private static void deleteAllUsers() {
        System.out.println("Testing all delete Users ----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_URI+"/user/");
    }
    
    // Main Method
	public static void main() {
		// Get All User
		listAllUsers();
		// Display USers
        getUser();
        // Create a new User
        createUser();
        listAllUsers();
     // Update a existing user
        updateUser();
        listAllUsers();
        // Delete all users
        deleteAllUsers();
        listAllUsers();
		
	}

}
