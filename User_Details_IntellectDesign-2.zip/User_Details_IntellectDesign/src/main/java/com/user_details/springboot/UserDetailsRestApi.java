package com.user_details.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(scanBasePackages={"com.user_details.springboot"})
public class UserDetailsRestApi {

	public static void main(String[] args) {
		SpringApplication.run(UserDetailsRestApi.class, args);
	}
}
